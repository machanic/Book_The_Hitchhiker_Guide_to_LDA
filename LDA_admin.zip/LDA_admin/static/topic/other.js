function lunbo(){
        var timer;
        var index = 0;
        var len = 3;
        function run(offset){
            var left = parseInt($('.list').css("left"));
            var newLeft = left + offset;
            $('.list').animate({'left': newLeft}, 1000, 'swing',function () {
                    if(newLeft > -1000){
                        $('.list').css("left","-3000px");
                    }
                    if(newLeft < -3000){
                        $('.list').css("left","-1000px");
                    }
            });
        }
        var callback = function(){
            if(index == 2){
                index = -1;
            }
            index++;
            run(-1000);
        }
        function play(){
            clearInterval(timer);
            timer = setInterval(function(){
                callback();
            },3500);
        }
        $('.container').hover(function(){
                clearInterval(timer);
            },function(){
                play();
            });
        $('.prev').on('click',function(){
            if(index == 0){
                index = 3;
            }
            index--;
    
            var left = parseInt($(this).parent().children('.list').css("left"));
            var newLeft = left + 1000;
            $(this).parent().children('.list').animate({'left': newLeft}, 300, 'swing',function (){
                    if(newLeft > -1000){
                        $(this).parent().children('.list').css("left","-3000px");
                    }
                    if(newLeft < -3000){
                        $(this).parent().children('.list').css("left","-1000px");
                    }
            });
        });
        $('.next').on('click',function(){
        	var left = parseInt($(this).parent().children('.list').css("left"));
            var newLeft = left - 1000;
            $(this).parent().children('.list').animate({'left': newLeft}, 300, 'swing',function (){
                    if(newLeft > -1000){
                        $(this).parent().children('.list').css("left","-3000px");
                    }
                    if(newLeft < -3000){
                        $(this).parent().children('.list').css("left","-1000px");
                    }
            });
        });
        play();
}
lunbo();
var timer;
var ajflag=true;
$(".cont_top").on('click',function(){
		$('.cont_data').css('height',1);
			$('.cont_data').hide();
			$('.cont_data').show();
			if(!($(this).parent().children()[2])){
		    	$(this).parent().append($('.cont_data'));
		    		adddiv_show();
				}else{
					$('.none').append($('.cont_data'));
				}
	 		var value = $(this).attr('data-id');
		    ajax_request(value);
	});			
function adddiv_show(){
	var odiv=document.getElementById("cont_data");
	var index=1;
	var timer=setInterval(function(){
	   	odiv.style.height = odiv.offsetHeight+22+'px';
	   	index++;
	   	if(index==60){
  		clearInterval(timer);
  		}
	    },0.2);
  };
$(".url1").on('click',function(){
 	$('.name2').hide();
 	$('.name1').show();
 	});
$(".url2").on('click',function(){
 	$('.name2').show();
 	$('.name1').hide();
 	});
function ajax_request(value){
	$(".mask").css("opacity",0.8);
		$.ajax({
	            url: "/request_one",
	            dataType: 'json',
	            data: {
	                topic_id: value
	            }
	        })
	        .done(function( data ){
	        	$(".mask").css("opacity",0);
	        	$('.short-text').removeAttr('value');
	         	$('.short-text').prop('value',data.label_name);
	         	$('.len').prop('value',data.min_len);
	        	var html='';
	        	var ohtml='';
	        	for(var i=0;i<data.label_words.length;i++){
	           		html+="<span class='label label-default div_h' style='cursor:pointer;background-color:#333'> " + data.label_words[i] + "  </span> ";
	           		if(i!=0 && (i+1)%4==0){
	           			html+="</br>";
	           		}
	        	}
	        	$('.selected_words').empty();
	        	$('.selected_words').append(html);
	        	var flagg=true;
	        	for(var i=0; i < data.typical_words.length; i++){
	        		for(var j=0; j < data.label_words.length; j++){
	        			if(data.typical_words[i] == data.label_words[j]){
	        				data.typical_words[i]=[data.label_words[j],'a'];
	        			}
	        		}
	        	}
	        	for(var i=0; i < data.typical_words.length; i++){
	        		flagg=true;
	        		for(var j=1; j < 2; j++){
	        				if(data.typical_words[i][1] == 'a' && flagg ){
	        				
	        					flagg = false;
	        					ohtml +="<span class='label label-default div_h' style='cursor:pointer;background-color:#333'> " + data.typical_words[i][0] + "  </span> ";
	        				}else if( flagg ){
	        					flagg = false;
	        					ohtml +="<span class='label label-default div_h' style='cursor:pointer' > " + data.typical_words[i] + "  </span>";
	        				}
	        			}
	        		if( i!=0 && (i+1)%3 == 0){
	        				ohtml += "</br>";
	        			}
	        		}
	        	
	        	$('.typical_words').empty();
	        	$('.typical_words').append(ohtml);
	        	var shtml="";
	        	for(var i=0;i<data.stocks.length;i++){
	        		shtml+="<span class='label label-default div_h' style='cursor:pointer' > " + data.stocks[i] + "  </span>";
	        		if( i!=0 && (i+1)%3 == 0){
	        				shtml += "</br>";
	        		}
	        	}
	        	$('.stocks').empty();
	        	$('.stocks').append(shtml);

	        	var prodata=[];
	        	for(var i in data.docs){
	        		prodata.push(data.docs[i]);
	        	}
	        	var prohtml='';

	        	for(var i=0;i<prodata.length;i++){
	        		for(var j=0;j<prodata[i].length;j++){
	        			var m=j+1;
	        			prohtml +="&#40;" + m + "&#41; "+" <a style='color:black;margin-right:20px' href="+ prodata[i][j].url +" > " + prodata[i][j].title + "&#46; </a>";
	        		}
	        		prohtml +="<div style='border-bottom:1px solid black'></div>";		
	        	}
	        	$('.pro-z').empty();
	        	$('.pro-z').append(prohtml);

	        	$('.submit_button').attr('id','submit_'+data.topic_id);
	        	$('.len').attr('id','count_'+ data.topic_id);
	        	$('.short-text').attr('id','label_'+ data.topic_id);
	        	$('.select_wordd').attr('name','submit_td_'+ data.topic_id);
	        	$('.typical_words').attr('name',data.topic_id);
	        	$('.model').attr('id',data.topic_id);
	        	$('.submit_button').attr('id','submit_' + data.topic_id);
	        	$('.selected_words').attr('name','select_p_' + data.topic_id);
	        	$('.typical_words').attr('name',data.topic_id);

	        	// 这是提交
		        $("td[type='select_word'] .selected_words").children().click(function(){
						var id = $(this).parents("tr").attr("id");
						
						var other = $(".typical_words[name='"+id+"'] .label:contains('"+ $(this).html() + "')").html();

						$(".typical_words[name='"+id+"'] .label:contains('"+ $(this).html() + "')").css({"background-color": "#777777"});
						
						$(this).remove();
						$("#count_"+id).val($("td[name='submit_td_"+id+"'] .label").length);				

				});
					$(".typical_words").find(".label").click(function(){
						var id = $(this).parent(".typical_words").attr("name");

						var len = $("td[name='submit_td_"+id+"']").find(".selected_words .label").length;
						
						var old_color = $(this).css("background-color");
						
						$(this).css({"background-color": "#333"});
						if(len%4 == 0 && len != 0){
							$("td[name='submit_td_"+id+"']").find(".selected_words").append($("<br />")).append( $(this).clone());
						}else{
							$("td[name='submit_td_"+id+"']").find(".selected_words").append( $(this).clone());
						}
						$("#count_"+id).val($("td[name='submit_td_"+id+"'] .label").length);


						$("td[type='select_word'] .selected_words").children().click(function(){
								
								var other = $(".typical_words[name='"+id+"'] .label:contains('"+ $(this).html() + "')").html();
								$(".typical_words[name='"+id+"'] .label:contains('"+ $(this).html() + "')").css({"background-color":old_color});
								
								$(this).remove();
								$("#count_"+id).val($("td[name='submit_td_"+id+"'] .label").length);				

						});
					});
	        	

	        	var timeover=0;
	        	var timeoverflow=setInterval(function (){
	        		var oheight = $('.grid').css('height');
					$('.cont_data').css('height',oheight);
					timeover++;
					if(timeover==5){
	        		clearInterval(timeoverflow);
	        	}
	        	},1000)
	        });	        	
  }
dialog_U();
function dialog_U() {
	$("a.submit_button").click(function(){
		var that = $(this);
		var id = $(this).attr("id").substring(7);
		var words = "";
		$("p[name='select_p_"+id+"']").children().each(function(){ 
			if( $.trim($(this).html()).length > 0 ){
			words += $.trim($(this).html()) + "," ;
		}
		});
		words = words.substring(0, words.length - 1);
		var min_len = $("#count_"+id).val();
		var label_name = $("#label_"+id).val()
		if($.trim(label_name) == "" || min_len == 0 || $.trim(words)=="" ){
			Dialog.alert("请仔细检查您的输入");
			return;
		}
		//TODO
		$.ajax({
					url: "/submit_token",
					data: {"topic_id":id, "words":words, "min_len":min_len, "label_name":label_name},
					cache: false,
					async: true,
					type: 'GET',
					dataType: 'text',
					timeout: 10000,
					error: function() {
						Dialog.alert('对不起，服务器响应超时，请联系管理员');
					},
					success: function(data) {
						if(data == "success"){
							Dialog.alert("提交成功！");
							that.parent().parent().parent().parent().parent().parent().children().children('.model_buttonname').html(label_name);

						}else if (data == "too_long_min_len"){
							Dialog.alert("对不起,不能提交,请确保最小匹配词数 小于等于 实际词数");
						}
					}
			});
		});

};