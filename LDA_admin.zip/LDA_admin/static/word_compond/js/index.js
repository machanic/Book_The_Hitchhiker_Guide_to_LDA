(function(){
	var main={
		init:function(){
			this.setmain();
			
		},
		lunbo:function(){
	        var timer;
	        var index = 0;
	        var len = 3;
	        function run(offset){
	            var left = parseInt($('.list').css("left"));
	            var newLeft = left + offset;

	            $('.list').animate({'left': newLeft}, 1000, 'swing',function (){
	                    if(newLeft > -1000){
	                        $('.list').css("left","-3000px");
	                    }
	                    if(newLeft < -3000){
	                        $('.list').css("left","-1000px");
	                    }
	            });

	        }
	        var callback = function(){
	            if(index == 2){
	                index = -1;
	            }
	            index++;
	            run(-1000);
	        }
	        function play(){
	            clearInterval(timer);
	            timer = setInterval(function(){
	                callback();
	            },3500);
	        }
	        $('.container').hover(function(){
	                clearInterval(timer);
	            },function(){
	                play();
	            });
	        $('.prev').on('click',function(event){
	            if(index == 0){
	                index = 3;
	            }
	            index--;
	    
	            var left = parseInt($(this).parent().children('.list').css("left"));
	            var newLeft = left + 1000;
	            $(this).parent().children('.list').animate({'left': newLeft}, 300, 'swing',function (){
	                    if(newLeft > -1000){
	                        $(this).parent().children('.list').css("left","-3000px");
	                    }
	                    if(newLeft < -3000){
	                        $(this).parent().children('.list').css("left","-1000px");
	                    }
	            });

	              
            		event.stopPropagation();
        
	        });
	        $('.next').on('click',function(event){
	        	var left = parseInt($(this).parent().children('.list').css("left"));
	            var newLeft = left - 1000;
	            $(this).parent().children('.list').animate({'left': newLeft}, 300, 'swing',function (){
	                    if(newLeft > -1000){
	                        $(this).parent().children('.list').css("left","-3000px");
	                    }
	                    if(newLeft < -3000){
	                        $(this).parent().children('.list').css("left","-1000px");
	                    }
	            });
	            event.stopPropagation();
	        });
	        play();
	        $('.list').each(function(){

	        })			
		},
		setmain:function(){
			var omain=this;
			var otimer=false;
			$('.content').empty();
			$.ajax({
				url: "../newword_compond",
				dataType: 'json'
				})
				.done(function( data ){
					var data_key=[];
					var data_value=[];
					for(var i=0; i<data.length;i++){
						for( var key in data[i] ){
							data_key.push( key );
							data_value.push( data[i][key]);
						}
					}
					for(var i=0;i<data_key.length;i++){
						var owarp = $('<div></div>');
						owarp.addClass('warp');
						var ocont_top = $('<div></div>');
						ocont_top.addClass('cont_top');
						var ocont_top_id = $('<span>'+data_key[i]+'</span>');
						ocont_top_id.addClass('cont_top_id');
						$(ocont_top).append(ocont_top_id);
						$(owarp).append(ocont_top);
						// 关键词
						var obottom = $('<div></div>');
						obottom.addClass('bottom');
						for(var j=0;j<data_value[i].length;j++){

							var ocontainer = $('<div></div>');
							ocontainer.addClass('container');
							ocontainer.attr('data-id',j);
							var oa=$('<a href="javascript:void(0);">&lt;</a>');
							oa.addClass('arrow').addClass('prev');
							var ta=$('<a href="javascript:void(0);">&gt;</a>');
							ta.addClass('arrow').addClass('next');
							
							var olist = $('<div style="left:-1000px;"></div>');
							olist.addClass('list');
							var oul = $('<ul></ul>');
							oul.addClass('aaa');
							var nli=$('<li></li>');
							$(oul).append(nli);
							for(var k=0;k<data_value[i][j].abstract.length;k++){
								
								var oli = $('<li>'+data_value[i][j].abstract[k]+'</li>');
								$(oul).append(oli);
							}
							var neli=$('<li></li>');
							$(oul).append(neli);
							$(olist).append(oul);
							$(ocontainer).append(olist);
							$(ocontainer).append(oa);
							$(ocontainer).append(ta);
							$(obottom).append(ocontainer);
						}
						$(owarp).append(obottom);
						$('.content').append(owarp);
						otimer=true;
					}
					var otime=setInterval(function(){
						if(otimer){
						omain.lunbo();
						omain.odisplay();
						clearInterval(otime);
						}
					},1000)


			});
		},
		odisplay:function(){
			var omain=this;
			$(".container").on('click',function(){
				var cthis = $(this);
				var str=$(this).parent().parent().children().children('.cont_top_id').html();
				
				$('.cont_data').css('height',1);
					$('.cont_data').show();

					if(!($(this).children()[3])){
				    	$(this).append($('.cont_data'));
				    	omain.solw();
				    	$(".container").css('height',65);
				    	
					}else{
						$('.none').append($('.cont_data'));
					}
					var num = $(this).attr('data-id');
					$.ajax({
					url: "../newword_compond",
					dataType: 'json'
					})
					.done(function( data ){

						var odata={};
						for(var i=0;i<data.length;i++){
							for(var key in data[i]){
								odata[key] = data[i][key];
							}
						}

						$('.cont_data').empty();
						var oul = $('<ul></ul>');
						for(var i=0;i<odata[str][num].docs.length;i++){
							var oli = $('<li></li>')
							var ospan = $('<span>'+odata[str][num].docs[i].datetime+'<span><br>');
							var oa = $('<a href="'+odata[str][num].docs[i].url+'">titile: '+odata[str][num].docs[i].title+'</a>');
							var tspan = $('<span>url: '+odata[str][num].docs[i].url+'</span>');
							$(oli).append(ospan).append(oa).append(tspan);
							$(oul).append(oli);
						}
						
						$('.cont_data').append(oul);
						var theight = parseInt($('.cont_data').children('ul').css('height'))+67;
						$(cthis).css('height',theight).children('.arrow').css('top',36); 

					});
				 		
				});	
		},
		solw:function(){
				var bb=document.getElementById("cont_data");
				var index=1;
				var timer=setInterval(function(){
					   	bb.style.height = bb.offsetHeight+22+'px';
					   	index++;
					   	if(index==200){
				  			clearInterval(timer);
				  		}
				    },0.2);
		}
	}
	main.init();
})()
